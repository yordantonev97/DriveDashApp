# DriveDash Native PiP Proof-of-Concept

This repository is intentionally small. Its only goal is to answer one question on a real iPhone:

> Can DriveDash start native iOS Picture-in-Picture and keep that PiP window visible after opening Waze or Google Maps?

## What it does

1. Shows a native SwiftUI screen.
2. Creates `AVPictureInPictureController` from a real `AVPlayerLayer`.
3. Starts PiP only after the user taps **Start Drive**.
4. Waits until iOS confirms PiP actually started.
5. Then opens Waze or Google Maps using their public web/deep-link entry points.
6. The user checks whether the PiP window remains above navigation.

This is a proof-of-concept. The PiP contains a placeholder video, not Spotify yet.

## Cloud compile without a Mac

The included `codemagic.yaml` creates an unsigned iOS Simulator build. This verifies that the native Swift/Xcode project compiles without requiring Apple signing.

A simulator build cannot prove cross-app PiP behavior. The final PiP test requires a signed build installed on a physical iPhone.

## Why XcodeGen

`project.yml` describes the Xcode project in text. Codemagic installs XcodeGen and generates `DriveDash.xcodeproj` in the cloud, so no Mac is needed just to maintain the repository.
